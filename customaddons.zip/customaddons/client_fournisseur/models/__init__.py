# -*- coding: utf-8 -*-

from . import client
from . import fournisseur